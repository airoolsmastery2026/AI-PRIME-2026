# AI PRIME 2026 - Hướng dẫn Cấu hình và Triển khai trên Vercel

Đây là hướng dẫn từng bước để chạy ứng dụng AI PRIME cục bộ (local) và triển khai lên Vercel một cách hoàn chỉnh.

## Kiến trúc Ứng dụng

Ứng dụng này được xây dựng với kiến trúc an toàn và hiện đại:
- **Frontend (Giao diện người dùng)**: Một ứng dụng React tĩnh, được phục vụ từ thư mục gốc. Giao diện người dùng chỉ chịu trách nhiệm hiển thị và tương tác, không chứa khóa API.
- **Backend (Logic máy chủ)**: Các hàm Serverless Functions được đặt trong thư mục `/api`. Các hàm này chịu trách nhiệm xử lý logic, gọi đến các dịch vụ AI (như Google Gemini) một cách an toàn và bảo mật.

---

## 1. Hướng dẫn Chạy Ứng dụng Cục bộ (Local Development)

### Yêu cầu
- Đã cài đặt [Node.js](https://nodejs.org/) (phiên bản 20.x trở lên).
- Đã cài đặt [Vercel CLI](https://vercel.com/docs/cli). Nếu chưa, chạy lệnh: `npm install -g vercel`.

### Các bước Cài đặt
1.  **Clone Repository**:
    ```bash
    git clone <your-repository-url>
    cd <your-repository-name>
    ```

2.  **Cài đặt Dependencies**:
    Chạy lệnh sau để cài đặt tất cả các gói phụ thuộc cần thiết cho cả frontend và backend:
    ```bash
    npm install
    ```

3.  **Thiết lập Biến Môi trường**:
    Để backend có thể gọi Gemini API, bạn cần cung cấp `API_KEY`. Tạo một file mới ở thư mục gốc có tên là `.env.local` và thêm nội dung sau:
    ```
    API_KEY=your_gemini_api_key_here
    ```
    **Lưu ý**: Thay `your_gemini_api_key_here` bằng khóa API Gemini thực của bạn. File `.env.local` sẽ không được đưa lên Git và giữ cho khóa của bạn an toàn.

4.  **Khởi động Server Development**:
    Chạy lệnh sau để khởi động server phát triển của Vercel:
    ```bash
    vercel dev
    ```
    Lệnh này sẽ:
    - Khởi động một server tại `http://localhost:3000`.
    - Phục vụ các file frontend tĩnh của bạn.
    - Tự động chạy các hàm backend trong thư mục `/api`.
    - Tải biến môi trường từ file `.env.local`.

Bây giờ, bạn có thể truy cập `http://localhost:3000` trên trình duyệt để sử dụng ứng dụng.

---

## 2. Hướng dẫn Triển khai lên Vercel (Deployment)

### Yêu cầu
- Một tài khoản [Vercel](https://vercel.com) đã kết nối với tài khoản GitHub của bạn.
- Code của dự án đã được đẩy lên một repository trên GitHub.

### Các bước Triển khai
1.  **Import Dự án vào Vercel**:
    - Truy cập [Vercel Dashboard](https://vercel.com/dashboard).
    - Nhấp vào "Add New..." -> "Project".
    - Chọn "Import Git Repository" và chọn repository GitHub của bạn.

2.  **Cấu hình Dự án**:
    Vercel sẽ tự động phát hiện cấu trúc của bạn. Bạn không cần thay đổi các cài đặt `Build & Output Settings`. Cứ để mặc định và Vercel sẽ xử lý mọi thứ.

3.  **Cấu hình Biến Môi trường (QUAN TRỌNG)**:
    - Trong trang cài đặt dự án của bạn trên Vercel, đi đến tab "Settings" -> "Environment Variables".
    - Thêm một biến mới:
      - **Name**: `API_KEY`
      - **Value**: Dán khóa API Gemini của bạn vào đây.
    - Nhấp "Save". Đây là bước quan trọng nhất để bảo vệ khóa API của bạn trên môi trường production.

4.  **Triển khai**:
    - Nhấp vào nút "Deploy".
    - Vercel sẽ tự động build và triển khai ứng dụng của bạn. Sau vài phút, bạn sẽ nhận được một URL công khai cho ứng dụng của mình.

---

## Giải thích file `vercel.json`

File `vercel.json` là file cấu hình để chỉ dẫn cho Vercel cách build và phục vụ ứng dụng của bạn.

```json
{
  "functions": {
    "api/*.ts": {
      "maxDuration": 45
    }
  },
  "rewrites": [
    {
      "source": "/((?!api/).*)",
      "destination": "/index.html"
    }
  ],
  "headers": [
    {
      "source": "/(.*)",
      "headers": [
        { "key": "X-Content-Type-Options", "value": "nosniff" },
        { "key": "X-Frame-Options", "value": "DENY" },
        { "key": "X-XSS-Protection", "value": "1; mode=block" }
      ]
    }
  ]
}
```

- **`functions`**: Cấu hình này chỉ định rằng tất cả các file TypeScript trong thư mục `api/` sẽ có thời gian thực thi tối đa là 45 giây. Điều này rất quan trọng cho các tác vụ AI mất thời gian như tạo video. Vercel sẽ tự động phát hiện và sử dụng phiên bản Node.js phù hợp.
- **`rewrites`**: Đây là cấu hình quan trọng nhất cho một ứng dụng trang đơn (Single Page Application - SPA). Nó ra lệnh cho Vercel: "Với bất kỳ yêu cầu nào không bắt đầu bằng `/api/`, hãy trả về file `index.html`". Điều này cho phép React (phía client) xử lý việc định tuyến URL (ví dụ: `/agents`, `/video`) mà không gây ra lỗi 404 trên server. Các yêu cầu đến `/api/...` sẽ được chuyển đến các hàm backend một cách chính xác.